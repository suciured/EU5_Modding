# If you want to create a situation in the UI:

# 1. Check the common.gui file to see the different building blocks that can be used to create a situation.
# 2. You should create a new file in the situations folder with the name of the situation.
# 3. Your new created file should have the same structure as the other situation files. Specially using the type situation_panel.
# Recommendation: Use as a base layout a situation that has similar building blocks as yours. A good situation to take a look right now is the rise_of_the_ottomans