COMMON/COAT_OF_ARMS/OPTIONS
===========================
Purpose:
- Data / assets under: common/coat_of_arms/options

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
