COMMON/MODIFIER_TYPE_DEFINITIONS
================================
Purpose:
- Data / assets under: common/modifier_type_definitions

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
