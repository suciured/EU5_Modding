COMMON/GAME_CONCEPTS
====================
Purpose:
- Data / assets under: common/game_concepts

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
