COMMON/ACHIEVEMENTS
===================
Purpose:
- Data / assets under: common/achievements

Observed in extracted data:
- 3 text-like file(s) detected in this directory.
