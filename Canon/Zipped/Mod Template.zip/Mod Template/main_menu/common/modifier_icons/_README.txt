COMMON/MODIFIER_ICONS
=====================
Purpose:
- Data / assets under: common/modifier_icons

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
