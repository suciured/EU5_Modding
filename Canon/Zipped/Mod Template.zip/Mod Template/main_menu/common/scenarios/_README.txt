COMMON/SCENARIOS
================
Purpose:
- Data / assets under: common/scenarios

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
