COMMON/SCRIPT_VALUES
====================
Purpose:
- Data / assets under: common/script_values

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
