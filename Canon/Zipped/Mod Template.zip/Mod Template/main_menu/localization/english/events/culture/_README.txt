LOCALIZATION/ENGLISH/EVENTS/CULTURE
===================================
Purpose:
- Data / assets under: localization/english/events/culture

Observed in extracted data:
- 5 text-like file(s) detected in this directory.
