LOCALIZATION/ENGLISH/EVENTS/ECONOMY
===================================
Purpose:
- Data / assets under: localization/english/events/economy

Observed in extracted data:
- 10 text-like file(s) detected in this directory.
