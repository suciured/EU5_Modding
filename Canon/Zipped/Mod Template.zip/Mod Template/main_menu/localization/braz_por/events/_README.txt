LOCALIZATION/BRAZ_POR/EVENTS
============================
Purpose:
- Data / assets under: localization/braz_por/events

Observed in extracted data:
- 22 text-like file(s) detected in this directory.
