LOCALIZATION/BRAZ_POR/EVENTS/RELIGION
=====================================
Purpose:
- Data / assets under: localization/braz_por/events/religion

Observed in extracted data:
- 28 text-like file(s) detected in this directory.
