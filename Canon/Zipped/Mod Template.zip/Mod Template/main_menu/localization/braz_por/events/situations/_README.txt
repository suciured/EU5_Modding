LOCALIZATION/BRAZ_POR/EVENTS/SITUATIONS
=======================================
Purpose:
- Data / assets under: localization/braz_por/events/situations

Observed in extracted data:
- 24 text-like file(s) detected in this directory.
