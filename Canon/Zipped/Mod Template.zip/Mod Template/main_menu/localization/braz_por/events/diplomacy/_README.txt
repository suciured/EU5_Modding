LOCALIZATION/BRAZ_POR/EVENTS/DIPLOMACY
======================================
Purpose:
- Data / assets under: localization/braz_por/events/diplomacy

Observed in extracted data:
- 7 text-like file(s) detected in this directory.
