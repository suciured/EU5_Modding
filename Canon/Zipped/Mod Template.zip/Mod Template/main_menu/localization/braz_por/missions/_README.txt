LOCALIZATION/BRAZ_POR/MISSIONS
==============================
Purpose:
- Data / assets under: localization/braz_por/missions

Observed in extracted data:
- 4 text-like file(s) detected in this directory.
