GUI/SCRIPTED_WIDGETS
====================
Purpose:
- Data / assets under: gui/scripted_widgets

Observed in extracted data:
- 0 text-like file(s) detected in this directory.
