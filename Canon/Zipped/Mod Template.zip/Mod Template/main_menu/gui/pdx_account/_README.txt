GUI/PDX_ACCOUNT
===============
Purpose:
- Data / assets under: gui/pdx_account

Observed in extracted data:
- 6 text-like file(s) detected in this directory.
