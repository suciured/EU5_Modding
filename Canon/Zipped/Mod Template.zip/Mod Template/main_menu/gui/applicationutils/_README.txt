GUI/APPLICATIONUTILS
====================
Purpose:
- Data / assets under: gui/applicationutils

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
