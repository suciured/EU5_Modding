GUI/NOTIFICATIONS
=================
Purpose:
- Data / assets under: gui/notifications

Observed in extracted data:
- 1 text-like file(s) detected in this directory.
