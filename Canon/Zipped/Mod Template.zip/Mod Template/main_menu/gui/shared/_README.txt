GUI/SHARED
==========
Purpose:
- Data / assets under: gui/shared

Observed in extracted data:
- 38 text-like file(s) detected in this directory.
