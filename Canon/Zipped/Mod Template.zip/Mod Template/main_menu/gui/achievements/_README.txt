GUI/ACHIEVEMENTS
================
Purpose:
- Data / assets under: gui/achievements

Observed in extracted data:
- 2 text-like file(s) detected in this directory.
