MAP_DATA
========
Purpose:
- Map-related data under: map_data

Observed in extracted base data:
- 5 text file(s) detected in this directory.
