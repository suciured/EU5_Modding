MAP_DATA/NAMED_LOCATIONS
========================
Purpose:
- Map-related data under: map_data/named_locations

Observed in extracted base data:
- 1 text file(s) detected in this directory.
