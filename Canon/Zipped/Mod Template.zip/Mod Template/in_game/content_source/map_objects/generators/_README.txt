CONTENT_SOURCE/MAP_OBJECTS/GENERATORS
=====================================
Purpose:
- Content source data under: content_source/map_objects/generators

Observed in extracted base data:
- 1 file(s).
