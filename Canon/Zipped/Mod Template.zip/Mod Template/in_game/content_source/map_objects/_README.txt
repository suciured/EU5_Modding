CONTENT_SOURCE/MAP_OBJECTS
==========================
Purpose:
- Content source data under: content_source/map_objects

Observed in extracted base data:
- 0 file(s).
