CONTENT_SOURCE/MAP_OBJECTS/AMBIENCE_GENERATORS
==============================================
Purpose:
- Content source data under: content_source/map_objects/ambience_generators

Observed in extracted base data:
- 1 file(s).
