GUI/SORT_KEYS
=============
Purpose:
- UI definitions under: gui/sort_keys

Observed in extracted base data:
- 1 GUI/text file(s) detected in this directory.
