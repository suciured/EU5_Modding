GUI/ATTRIBUTE_COLUMNS
=====================
Purpose:
- UI definitions under: gui/attribute_columns

Observed in extracted base data:
- 37 GUI/text file(s) detected in this directory.
