GUI/SHARED
==========
Purpose:
- UI definitions under: gui/shared

Observed in extracted base data:
- 48 GUI/text file(s) detected in this directory.
