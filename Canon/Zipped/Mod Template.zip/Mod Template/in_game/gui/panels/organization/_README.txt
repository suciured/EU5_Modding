GUI/PANELS/ORGANIZATION
=======================
Purpose:
- UI definitions under: gui/panels/organization

Observed in extracted base data:
- 49 GUI/text file(s) detected in this directory.
