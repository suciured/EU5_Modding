GUI/PANELS/MARKET
=================
Purpose:
- UI definitions under: gui/panels/market

Observed in extracted base data:
- 2 GUI/text file(s) detected in this directory.
