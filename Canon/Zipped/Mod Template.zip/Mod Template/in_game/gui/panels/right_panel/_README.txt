GUI/PANELS/RIGHT_PANEL
======================
Purpose:
- UI definitions under: gui/panels/right_panel

Observed in extracted base data:
- 1 GUI/text file(s) detected in this directory.
