GUI/PANELS
==========
Purpose:
- UI definitions under: gui/panels

Observed in extracted base data:
- 0 GUI/text file(s) detected in this directory.
