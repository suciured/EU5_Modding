GUI/PANELS/RELIGION
===================
Purpose:
- UI definitions under: gui/panels/religion

Observed in extracted base data:
- 3 GUI/text file(s) detected in this directory.
