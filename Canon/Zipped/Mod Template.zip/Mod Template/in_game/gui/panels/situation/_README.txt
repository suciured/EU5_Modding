GUI/PANELS/SITUATION
====================
Purpose:
- UI definitions under: gui/panels/situation

Observed in extracted base data:
- 24 GUI/text file(s) detected in this directory.
