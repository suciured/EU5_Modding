EVENTS/DIPLOMACY
================
Purpose:
- Event scripts under: events/diplomacy

Observed in extracted base data:
- 7 event file(s).
