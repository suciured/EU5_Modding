EVENTS/ECONOMY
==============
Purpose:
- Event scripts under: events/economy

Observed in extracted base data:
- 10 event file(s).
