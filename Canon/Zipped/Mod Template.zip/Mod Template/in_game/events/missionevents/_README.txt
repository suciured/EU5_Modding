EVENTS/MISSIONEVENTS
====================
Purpose:
- Event scripts under: events/missionevents

Observed in extracted base data:
- 3 event file(s).
