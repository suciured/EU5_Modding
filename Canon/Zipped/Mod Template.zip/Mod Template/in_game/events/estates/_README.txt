EVENTS/ESTATES
==============
Purpose:
- Event scripts under: events/estates

Observed in extracted base data:
- 6 event file(s).
