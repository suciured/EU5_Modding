EVENTS/GOVERNMENT
=================
Purpose:
- Event scripts under: events/government

Observed in extracted base data:
- 18 event file(s).
