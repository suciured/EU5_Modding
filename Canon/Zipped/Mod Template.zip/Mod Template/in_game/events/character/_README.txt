EVENTS/CHARACTER
================
Purpose:
- Event scripts under: events/character

Observed in extracted base data:
- 8 event file(s).
