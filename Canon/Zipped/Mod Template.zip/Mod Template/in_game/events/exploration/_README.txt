EVENTS/EXPLORATION
==================
Purpose:
- Event scripts under: events/exploration

Observed in extracted base data:
- 2 event file(s).
