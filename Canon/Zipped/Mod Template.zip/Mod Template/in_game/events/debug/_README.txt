EVENTS/DEBUG
============
Purpose:
- Event scripts under: events/debug

Observed in extracted base data:
- 2 event file(s).
