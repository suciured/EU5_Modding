FONTS
=====
Font assets and registration files.
Fonts affect UI readability and localization support.
