COMMON/subject_military_stances
============
Purpose:
- Definitions for: subject_military_stances

Observed in extracted base data:
- 2 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
