COMMON/historical_scores
============
Purpose:
- Definitions for: historical_scores

Observed in extracted base data:
- 1 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
