COMMON/resolutions
============
Purpose:
- Definitions for: resolutions

Observed in extracted base data:
- 24 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
