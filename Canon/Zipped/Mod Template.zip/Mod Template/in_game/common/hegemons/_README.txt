COMMON/hegemons
============
Purpose:
- Definitions for: hegemons

Observed in extracted base data:
- 5 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
