COMMON/scripted_relations
============
Purpose:
- Definitions for: scripted_relations

Observed in extracted base data:
- 32 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
