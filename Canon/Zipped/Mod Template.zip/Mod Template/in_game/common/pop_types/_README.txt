COMMON/pop_types
============
Purpose:
- Definitions for: pop_types

Observed in extracted base data:
- 1 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
