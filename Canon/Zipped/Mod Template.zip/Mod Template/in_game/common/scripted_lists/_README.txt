COMMON/scripted_lists
============
Purpose:
- Definitions for: scripted_lists

Observed in extracted base data:
- 3 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
