COMMON/country_interactions
============
Purpose:
- Definitions for: country_interactions

Observed in extracted base data:
- 70 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
