COMMON/cabinet_actions
============
Purpose:
- Definitions for: cabinet_actions

Observed in extracted base data:
- 64 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
