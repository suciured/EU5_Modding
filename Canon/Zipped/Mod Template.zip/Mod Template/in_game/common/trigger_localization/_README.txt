COMMON/trigger_localization
============
Purpose:
- Definitions for: trigger_localization

Observed in extracted base data:
- 38 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
