COMMON/international_organizations
============
Purpose:
- Definitions for: international_organizations

Observed in extracted base data:
- 34 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
