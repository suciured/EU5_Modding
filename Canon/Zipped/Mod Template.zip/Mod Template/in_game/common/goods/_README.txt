COMMON/goods
============
Purpose:
- Definitions for: goods

Observed in extracted base data:
- 6 text file(s) detected in this folder (some folders may be empty or contain non-text assets).
