﻿# possible - filters out achivements on game start so we dont have to check everything all the time
# happened - checks if achivement happened
# add the achievement to the chosen group (very easy, easy, medium, hard, very hard) in game\main_menu\common\achievement_groups.txt

# example 
#friend_in_need = {
#	possible = {
#	}
#
#	happened = {
#		treasury > 6
#	}
#}