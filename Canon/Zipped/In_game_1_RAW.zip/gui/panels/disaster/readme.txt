# If you want to create a disaster in the UI:

# 1. Check the common.gui file to see the different building blocks that can be used to create a disaster.
# 2. You should create a new file in the disasters folder with the name of the disaster.
# 3. Your new created file should have the same structure as the other disaster files. Specially using the type disaster_panel.
# Recommendation: Use as a base layout a disaster that has similar building blocks as yours.