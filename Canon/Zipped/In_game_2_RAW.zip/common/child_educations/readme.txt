﻿#<child education id> = {
#	modifier = { <character modifiers> }
#	country_modifier = { <country modifiers> }
#	price_to_select = <price>
#	price_to_deselect = <price>
#	allow = { <location triggers???> }
#}