﻿# Country Description Categories
# 
# empty objects only used to set country profile descriptions in lobby
#
# example :
# object_key = {}
#
# the localization keys used for those descriptions will be deduced from the object key
# loc key for the category name         : country_description_category_name_<object_key>
# loc key for the category description  : country_description_category_desc_<object_key>
#
# those categories can be used in the country definition in game/in_game/setup/countries