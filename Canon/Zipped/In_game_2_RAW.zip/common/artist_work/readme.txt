﻿# Work of art type. Types and benefits of different works of art.
#
# captured: can this work of art be captures (yes/no)
# allow: trigger to determine of the work of art type is allowed (root = character)
# location_modifier: modifier applied to the location of the work of art
# country_modifier: modifier applies to the owner of the work of art
# religion_scale_modifier: modifier applies to the whole religion