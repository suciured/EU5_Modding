﻿#<artist type id> = {
#	potential = { <country triggers> }
#}